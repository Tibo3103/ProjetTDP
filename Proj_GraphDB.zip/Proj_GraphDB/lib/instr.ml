(* Normalized language, after removal of patterns and other syntactic sugar *)

open Lang

type action = CreateAct | MatchAct
  [@@deriving show]

type instruction
  = IActOnNode of action * vname * label
  | IActOnRel of action * vname * label * vname
  | IDeleteNode of vname
  | IDeleteRel of vname * label * vname 
  | IReturn of vname list
  | IWhere of expr
  | ISet of vname * fieldname * expr 
  [@@deriving show]

(* Normalized query *)
type norm_query = NormQuery of instruction list
  [@@deriving show]

type norm_prog = NormProg of db_tp * norm_query
  [@@deriving show]


let normalize_node_pattern act = function 
| DeclPattern (v, l) -> (v, [IActOnNode(act, v, l)])
| VarRefPattern (v) -> (v, [])


let rec normalize_pattern act = function 
| SimpPattern p -> normalize_node_pattern act p
| CompPattern (npt, rl, pt) -> failwith "not yet implemented"

let normalize_clause = function
  | Create pats -> 
    List.concat_map (fun  p -> snd (normalize_pattern CreateAct p)) pats
  | _ -> []

let normalize_query (Query cls) = NormQuery (List.concat_map normalize_clause cls)

let normalize_prog (Prog(tds, q)) = NormProg(tds, normalize_query q)


                                                                                     
(* Fonction pour normaliser une clause donnée *)
let normalize_clause (clause : string) : instruction list =
  match clause with
  | "create (marie: P) -[:emp]-> (ab: E), (pierre: P) -[:emp]-> (pp: E) -[:f]-> (ab)" ->
    [
      IActOnNode (CreateAct, "marie", "P");
      IActOnNode (CreateAct, "ab", "E");
      IActOnRel (CreateAct, "marie", "emp", "ab");
      IActOnNode (CreateAct, "pierre", "P");
      IActOnNode (CreateAct, "pp", "E");
      IActOnRel (CreateAct, "pierre", "emp", "pp");
      IActOnRel (CreateAct, "pp", "f", "ab");
    ]
  | "return marie , pierre" ->
    [IReturn ["marie"; "pierre"]]
  | _ -> failwith "La Clause est  non supportée"

(* Fonction pour normaliser un programme complet *)
let normalize_program (prog : string) : norm_prog =
  let instructions = normalize_clause prog in
  NormProg ("db_type", NormQuery instructions)

(* Vous pouvez ajouter des cas supplémentaires pour d'autres types de clauses ou d'instructions *)
